var searchData=
[
  ['baud_847',['baud',['../class_bluetooth.html#acf970ac6083f539bc32cebc59aa57079',1,'Bluetooth']]],
  ['baudrate_848',['baudrate',['../struct_baud__t.html#a2c72661bd05e5fabf400223d23918290',1,'Baud_t']]],
  ['bdata_849',['Bdata',['../unionword__t.html#aeb3b265d4c9f7553477a6c1c038a06f1',1,'word_t']]],
  ['beep0_850',['beep0',['../classi_mag_car.html#a7328485ad44895739870fef8635b873d',1,'iMagCar']]],
  ['buffer_851',['buffer',['../union_saver.html#abc1a75858913168f8a56b54beb9c7028',1,'Saver']]]
];
