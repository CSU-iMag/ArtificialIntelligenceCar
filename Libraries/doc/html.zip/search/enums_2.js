var searchData=
[
  ['res_5fenum_971',['Res_enum',['../_m_c_p4452_8h.html#a576e88786113343a7782f07a762a61ac',1,'MCP4452.h']]],
  ['resval_5fenum_972',['ResVal_enum',['../_m_c_p4452_8h.html#a6b4cde3f8c35c6479225631d3a434a14',1,'MCP4452.h']]]
];
