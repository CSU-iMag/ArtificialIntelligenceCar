var searchData=
[
  ['noticeobject_924',['NoticeObject',['../struct_notice_layout.html#a6981199f94b9bb39c9f189cd35ac6538',1,'NoticeLayout']]]
];
