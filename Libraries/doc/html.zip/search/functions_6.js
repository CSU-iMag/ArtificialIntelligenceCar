var searchData=
[
  ['filter_5fmovave_5ft_703',['filter_movAve_t',['../classfilter__mov_ave__t.html#ac89cb45690e7cdfafd4aaf437d986f47',1,'filter_movAve_t']]]
];
