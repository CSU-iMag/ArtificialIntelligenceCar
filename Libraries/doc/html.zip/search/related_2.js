var searchData=
[
  ['storage_5fload_1008',['storage_load',['../class_mag_sensor.html#a803271033b6b1a8fe27eeea135c79dfd',1,'MagSensor']]],
  ['storage_5fsave_1009',['storage_save',['../class_mag_sensor.html#ab53da590043f5872f57c03ddf34da1ec',1,'MagSensor']]]
];
