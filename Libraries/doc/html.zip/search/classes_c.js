var searchData=
[
  ['resistance_587',['Resistance',['../struct_resistance.html',1,'']]]
];
