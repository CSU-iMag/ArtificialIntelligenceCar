var indexSectionsWithContent =
{
  0: "_abcdefghiklmnoprstuvw~æ",
  1: "abcdefhilmnprstw",
  2: "abcefgklmprstu",
  3: "_abcdefghiklmnoprstuw~",
  4: "_abcdefghiklmnprstuv",
  5: "fks",
  6: "kpr",
  7: "abdeklnrsu",
  8: "mpst",
  9: "_abcdefghiklmprstv",
  10: "gtæ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "related",
  9: "defines",
  10: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Friends",
  9: "Macros",
  10: "Pages"
};

